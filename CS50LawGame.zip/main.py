from random import randint
Number = randint(1,25)
for _ in range(5):
  Guess = input("Please guess the number between 1 and 25\n")
  Guess = int(Guess)
  if Number > Guess:
    print("too low")
  elif Number < Guess:
    print("too high")
  else:
    break 
if Guess == Number:
  print("Very good, you made it")
else: 
  print("the correct answer is ", end="")
  print(Number)